﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;

namespace WpfApp1
{
    public class TreeNode : NotifyPropertyChanged
    {
        private bool _isDraggable = true;
        private bool _isDropable = true;
        private bool _isEditable = true;
        private bool _isEditing;
        private bool _isExpanded;
        private bool _isLoading;
        private bool _isSelectable = true;
        private bool _isSelected;
        private bool _isVisible = true;
        private bool _isFuzzy;
        private bool _isBold = false;
        private string _name;
        private object? _tag;
        private object? _icon;
        private ObservableCollection<TreeNode> _children;

        public TreeNode()
        {
            _name = String.Empty;

            _children = new ObservableCollection<TreeNode>();

            this.Id = String.Empty;
        }

        public virtual string Id { get; set; }
        public int Order { get; set; }
        public bool IsDraggable { get => _isDraggable; set => this.OnPropertyChanged(ref _isDraggable, value); }
        public bool IsDropable { get => _isDropable; set => this.OnPropertyChanged(ref _isDropable, value); }
        public bool IsEditable { get => _isEditable; set => this.OnPropertyChanged(ref _isEditable, value); }
        public bool IsEditing { get => _isEditing; set => this.OnPropertyChanged(ref _isEditing, value); }
        public virtual bool IsExpanded { get => _isExpanded; set => this.OnPropertyChanged(ref _isExpanded, value); }
        public bool IsLoading { get => _isLoading; set => this.OnPropertyChanged(ref _isLoading, value); }
        public bool IsSelectable { get => _isSelectable; set => this.OnPropertyChanged(ref _isSelectable, value); }
        public virtual bool IsSelected { get => _isSelected; set => this.OnPropertyChanged(ref _isSelected, value); }
        public virtual string Name { get => _name; set => this.OnPropertyChanged(ref _name, value); }
        public object? Tag { get => _tag; set => this.OnPropertyChanged(ref _tag, value); }
        public virtual object? Icon { get => _icon; set => this.OnPropertyChanged(ref _icon, value); }
        public bool IsVisible { get => _isVisible; set => this.OnPropertyChanged(ref _isVisible, value); }
        public bool IsFuzzy { get => _isFuzzy; set => this.OnPropertyChanged(ref _isFuzzy, value); }
        public bool IsBold { get => _isBold; set => this.OnPropertyChanged(ref _isBold, value); }
        public ObservableCollection<TreeNode> Children { get => _children; set => this.OnPropertyChanged(ref _children, value); }
        public TreeNode? Parent { get; protected set; }

        internal void SetIsSelected(bool value)
        {
            _isSelected = value;

            if (!_isSelected && this.IsEditing)
            {
                this.IsEditing = false;
            }
        }
    }
}
