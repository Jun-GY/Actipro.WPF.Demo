﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using ActiproSoftware.Windows.Controls.Grids;

namespace WpfApp1
{
    public class DefaultTreeListBoxItemAdapter : TreeListBoxItemAdapter
    {
        public DefaultTreeListBoxItemAdapter()
        {
            this.ChildrenPath = "Children";
            this.IsEditingPath = "IsEditing";
            this.IsExpandedPath = "IsExpanded";
            this.IsLoadingPath = "IsLoading";
            this.IsSelectablePath = "IsSelectable";
            this.IsSelectedPath = "IsSelected";
        }

        protected bool IsAutoSorted { get; set; }

        public override IEnumerable GetChildren(TreeListBox ownerControl, object item)
        {
            if (item is TreeNode node)
            {
                if (this.IsAutoSorted)
                {
                    var collection = CollectionViewSource.GetDefaultView(node.Children);

                    collection.SortDescriptions.Add(new SortDescription("Order", ListSortDirection.Ascending));

                    collection.SortDescriptions.Add(new SortDescription("Name", ListSortDirection.Ascending));

                    return collection;
                }
                else
                {
                    return node.Children;
                }
            }
            else
            {
                return Enumerable.Empty<TreeNode>();
            }
        }

        public override bool GetIsDraggable(TreeListBox ownerControl, object item)
        {
            return item is TreeNode { IsDraggable: true };
        }

        public override bool GetIsEditable(TreeListBox ownerControl, object item)
        {
            return item is TreeNode { IsEditable: true };
        }

        public override bool GetIsEditing(TreeListBox ownerControl, object item)
        {
            return item is TreeNode { IsEditing: true };
        }

        public override bool GetIsExpanded(TreeListBox ownerControl, object item)
        {
            return item is TreeNode { IsExpanded: true };
        }

        public override bool GetIsLoading(TreeListBox ownerControl, object item)
        {
            return item is TreeNode { IsLoading: true };
        }

        public override bool GetIsSelected(TreeListBox ownerControl, object item)
        {
            return item is TreeNode { IsSelected: true };
        }

        public override bool GetIsSelectable(TreeListBox ownerControl, object item)
        {
            return item is not TreeNode model || model.IsSelectable;
        }

        public override string GetPath(TreeListBox ownerControl, object item)
        {
            return item is TreeNode model ? model.Name : String.Empty;
        }

        public override string GetSearchText(TreeListBox ownerControl, object item)
        {
            return item is TreeNode model ? model.Name : String.Empty;
        }

        public override void SetIsEditing(TreeListBox ownerControl, object item, bool value)
        {
            base.SetIsEditing(ownerControl, item, value);

            if (item is TreeNode node)
            {
                node.IsEditing = value;
            }
        }

        public override void SetIsExpanded(TreeListBox ownerControl, object item, bool value)
        {
            base.SetIsExpanded(ownerControl, item, value);

            if (item is TreeNode node)
            {
                node.IsExpanded = value;
            }
        }

        public override void SetIsSelected(TreeListBox ownerControl, object item, bool value)
        {
            base.SetIsSelected(ownerControl, item, value);

            if (item is TreeNode node)
            {
                node.SetIsSelected(value);
            }
        }
    }
}
