﻿using System;
using System.Collections.Concurrent;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;

namespace WpfApp1
{
    public abstract class NotifyPropertyChanged : INotifyPropertyChanged
    {
        protected bool IsBinded => this.PropertyChanged != null; 

        public event PropertyChangedEventHandler? PropertyChanged;

        protected internal virtual void OnPropertyChanged(string propertyName)
        {
            var parameter = new PropertyChangedEventArgs(propertyName);

            if (Application.Current.Dispatcher.CheckAccess())
            {
                this.PropertyChanged?.Invoke(this, parameter);
            }
            else
            {
                Application.Current.Dispatcher.BeginInvoke(
                    () => this.PropertyChanged?.Invoke(this, parameter));
            }
        }

        protected virtual bool OnPropertyChanged<TValue>(
            ref TValue field, TValue value, [CallerMemberName] string propertyName = "")
        {
            if (!Equals(field, value))
            { 
                field = value;

                this.OnPropertyChanged(propertyName);

                return true;
            }

            return false;
        }

    }
}
